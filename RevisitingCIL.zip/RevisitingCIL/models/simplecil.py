import logging
import numpy as np
import torch
from torch import nn
from torch.serialization import load
from tqdm import tqdm
from torch import optim
from torch.nn import functional as F
from torch.utils.data import DataLoader, random_split
from utils.inc_net import IncrementalNet,SimpleCosineIncrementalNet,SimpleVitNet
from models.base import BaseLearner
from utils.toolkit import target2onehot, tensor2numpy
from focal_loss.focal_loss import FocalLoss
import torch.nn.functional as nn_functional
import json
from peft import LoraConfig
from peft import get_peft_model
from torch import autocast
from torch.cuda.amp import GradScaler
import os
from utils.data_manager import DataManager
from torch.utils.data.sampler import WeightedRandomSampler
import copy
from torch.autograd import Variable
from utils.focal_loss_with_smoothing import FocalLossWithSmoothing

num_workers = 8

def get_fisher_diag(model, trainloader, params, empirical=True):
    fisher = {}
    for n, p in copy.deepcopy(params).items():
        p.data.zero_()
        fisher[n] = Variable(p.data)

    model.eval()
    for i, batch in enumerate(trainloader):
      if i%10==0:
        (_,data,label)=batch
        data=data.cuda()
        gt_label=label.cuda()
        model.zero_grad()
        logits = model(data)["logits"]
        if empirical:
            label = gt_label
        else:
            label = logits.max(1)[1].view(-1)
        fl_fct = FocalLoss(gamma=1)
        m = torch.nn.Softmax(dim=-1)
        loss = fl_fct(m(logits), label.long())
        loss.backward()

        for n, p in model.named_parameters():
            if p.requires_grad:
              fisher[n].data += p.grad.data ** 2 / (len(trainloader)*0.1)

    fisher = {n: p for n, p in fisher.items()}
    return fisher
    
class Learner(BaseLearner):
    def __init__(self, args):
        super().__init__(args)
        self._network = SimpleVitNet(args, True)
        self.min_lr = args['min_lr'] if args['min_lr'] is not None else 1e-8
        self.args=args
        self._tea_network=None
        self.p_old=None
        self.fisher_matrix=None
        self.fisher_matrix_new=None
        self.ewc_importance=1e4
        self.data_manager = DataManager(
        args["dataset"],
        args["shuffle"],
        args["seed"],
        args["init_cls"],
        args["increment"],
        )
    def after_task(self):
        self._known_classes = self._total_classes
    
    def get_ewc_loss(self, model, fisher, p_old):
      loss = 0
      for n, p in model.named_parameters():
          if p.requires_grad:
            #print(n)
            if n=="fc.weight":
              pass
            else:
              _loss = fisher[n] * (p - p_old[n]) ** 2
            loss += _loss.sum()
      return loss

    def replace_fc(self,trainloader, model, args):
        model = model.eval()
        embedding_list = []
        label_list = []
        with torch.no_grad():
            for i, batch in enumerate(trainloader):
                (_,data,label)=batch
                data=data.cuda()
                label=label.cuda()
                embedding=model.convnet(data)
                embedding_list.append(embedding.cpu())
                label_list.append(label.cpu())
        embedding_list = torch.cat(embedding_list, dim=0)
        label_list = torch.cat(label_list, dim=0)

        class_list=np.unique(self.train_dataset.labels)
        proto_list = []
        for class_index in class_list:
            # print('Replacing...',class_index)
            data_index=(label_list==class_index).nonzero().squeeze(-1)
            embedding=embedding_list[data_index]
            proto=embedding.mean(0)
            self._network.fc.weight.data[class_index]=proto
        return model
    
    def replace_fc_teacher(self,trainloader, model, teacher_model, args):
        model = model.eval()
        student_convnet = model.convnet
        teacher_convnet = teacher_model.convnet

        sd_student = student_convnet.state_dict()
        sd_teacher = teacher_convnet.state_dict()

        for key in sd_teacher:
          kl_lambda = float(self._known_classes/self._total_classes)
          sd_student[key]= (1-kl_lambda)*sd_student[key] + kl_lambda*sd_teacher[key]
        model.convnet.load_state_dict(sd_student)

        embedding_list = []
        label_list = []
        with torch.no_grad():
            for i, batch in enumerate(trainloader):
                (_,data,label)=batch
                data=data.cuda()
                label=label.cuda()
                #student
                embedding=model.convnet(data)
                embedding_list.append(embedding.cpu())
                label_list.append(label.cpu())
        embedding_list = torch.cat(embedding_list, dim=0)
        label_list = torch.cat(label_list, dim=0)

        class_list=np.unique(self.train_dataset.labels)
        proto_list = []
        #print(class_list)
        for class_index in class_list:
            # print('Replacing...',class_index)
            data_index=(label_list==class_index).nonzero().squeeze(-1)
            embedding=embedding_list[data_index]
            proto=embedding.mean(0)
            self._network.fc.weight.data[class_index]=proto
        return model

    def incremental_train(self, data_manager):
        self._cur_task += 1
        if self._cur_task == 0:
          batch_size=self.args["init_batch_size"]
        else:
          batch_size=self.args["tuned_batch_size"]
        self._total_classes = self._known_classes + data_manager.get_task_size(self._cur_task)
        self._network.update_fc(self._total_classes)
        logging.info("Learning on {}-{}".format(self._known_classes, self._total_classes))

        train_dataset = data_manager.get_dataset(np.arange(self._known_classes, self._total_classes),source="train", mode="train", )
        
        self.train_dataset=train_dataset
        self.data_manager=data_manager

        with open("./class_weights_assignment.json", 'r') as f:
          class_weights = json.load(f)
        
        sample_weights = [class_weights[i] for i in train_dataset.labels]

        sampler=WeightedRandomSampler(sample_weights, len(sample_weights))
        
        self.train_loader = DataLoader(train_dataset, batch_size=batch_size, sampler=sampler, num_workers=num_workers)

        test_dataset = data_manager.get_dataset(np.arange(0, self._total_classes), source="test", mode="test" )
        self.test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

        train_dataset_for_protonet=data_manager.get_dataset(np.arange(self._known_classes, self._total_classes),source="train", mode="test", )
        
        self.train_loader_for_protonet = DataLoader(train_dataset_for_protonet, batch_size=batch_size, sampler=sampler, num_workers=num_workers)

        if len(self._multiple_gpus) > 1:
            print('Multiple GPUs')
            self._network = nn.DataParallel(self._network, self._multiple_gpus)

        
        self._train(self.train_loader, self.test_loader, self.train_loader_for_protonet)
        
        if len(self._multiple_gpus) > 1:
            self._network = self._network.module

        if self._cur_task == 0:
            pass
        else:
            self._network.weight_align(self._total_classes - self._known_classes)
        
        
        train_loader_ewc = self.train_loader
        params = {n: p for n, p in self._network.named_parameters() if p.requires_grad}

        self.p_old = {}

        for n, p in copy.deepcopy(params).items():
          self.p_old[n] = Variable(p.data)

        params = {n: p for n, p in self._network.named_parameters() if p.requires_grad}

        self.fisher_matrix = get_fisher_diag(self._network, train_loader_ewc, params)

    def _train(self, train_loader, test_loader, train_loader_for_protonet):
        self._network.to(self._device)
        
        if self._cur_task == 0:
            optimizer = optim.SGD(
                self._network.parameters(),
                momentum=0.9,
                lr=self.args["init_lr"],
                weight_decay=self.args["init_weight_decay"]
            )
            
            scheduler = optim.lr_scheduler.CosineAnnealingLR(
                optimizer=optimizer, T_max=self.args['init_epoch'], eta_min=self.min_lr
            )
            self._init_train(train_loader, test_loader, optimizer, scheduler)
        else:
            if self._cur_task == 1:
              self.args["tuned_lr"]=5e-8
            elif self._cur_task == 2:
              self.args["tuned_lr"]=2.5e-4
            elif self._cur_task == 3:
              self.args["tuned_lr"]=7e-5
            elif self._cur_task == 4:
              self.args["tuned_lr"]=5e-7
            elif self._cur_task == 5:
              self.args["tuned_lr"]=4e-7
            elif self._cur_task == 6:
              self.args["tuned_lr"]=2e-7
            else:
              self.args["tuned_lr"]=1e-7

            optimizer = optim.SGD(
                self._network.parameters(),
                momentum=0.9,
                lr=self.args["tuned_lr"],
                weight_decay=self.args["tuned_weight_decay"]
            )
            
            scheduler = optim.lr_scheduler.CosineAnnealingLR(
                optimizer=optimizer, T_max=self.args['tuned_epoch'], eta_min=self.args["tuned_min_lr"]
            )
            self.replace_fc(train_loader_for_protonet, self._network, None)
            self._init_train(train_loader, test_loader, optimizer, scheduler)
        
        if self._cur_task == 0:
          self.replace_fc(train_loader_for_protonet, self._network, None)
        else:
          self.replace_fc_teacher(train_loader_for_protonet, self._network, self._tea_network, None)

    def _init_train(self, train_loader, test_loader, optimizer, scheduler):
        if self._cur_task == 0:
          prog_bar = tqdm(range(self.args["init_epoch"]))
        else:
          prog_bar = tqdm(range(self.args["tuned_epoch"]))
        
        scaler = GradScaler()

        for _, epoch in enumerate(prog_bar):
            self._network.train()

            losses = 0.0
            correct, total = 0, 0
            if torch.cuda.is_available():
              device = torch.device("cuda")
            else:
              device = torch.device("cpu")
            with open("./class_weights_assignment.json", 'r') as f:
              class_weights = json.load(f)
            weights_tensor = torch.tensor(class_weights, device=device)
            for i, (_, inputs, targets) in enumerate(train_loader):
                inputs, targets = inputs.to(self._device), targets.to(self._device)
                optimizer.zero_grad()
                with autocast(device_type='cuda', dtype=torch.float16):
                  logits = self._network(inputs)["logits"]

                  if self._cur_task==0:
                    weights_tensor=weights_tensor[0:30]
                  else:
                    weights_tensor=weights_tensor[0:30+self._cur_task*30]
                  
                  m = torch.nn.Softmax(dim=-1)
                  if self._cur_task==0:
                    weights_tensor=weights_tensor[0:30]
                  else:
                    weights_tensor=weights_tensor[0:30+self._cur_task*30]
                    for i in range(len(weights_tensor)):
                      if i>=0 and i<self._known_classes:
                        weights_tensor[i]=0.0
                    
                  if self._cur_task==0:
                    fl_fct = FocalLoss(gamma=1)
                    focal_loss = fl_fct(m(logits), targets.long())
                    loss=focal_loss
                  else:
                    ewc_loss = self.get_ewc_loss(self._network, self.fisher_matrix, self.p_old)
                    fl_fct = FocalLoss(gamma=1)
                    focal_loss = fl_fct(m(logits), targets.long())
                    loss=focal_loss+self.ewc_importance*ewc_loss
                
                scaler.scale(loss).backward()

                scaler.step(optimizer)
                scaler.update()
                losses += loss.item()
                
                _, preds = torch.max(logits, dim=1)
                correct += preds.eq(targets.expand_as(preds)).cpu().sum()
                total += len(targets)
            
            scheduler.step()
            
            
            train_acc = np.around(tensor2numpy(correct) * 100 / total, decimals=2)

            if epoch % 1 == 0:
                test_acc = self._compute_accuracy(self._network, test_loader)

                if self._cur_task == 0:
                  self.args['init_epoch']
                else:
                  self.args['init_epoch']=self.args['tuned_epoch']
                info = "Task {}, Epoch {}/{} => Loss {:.3f}, Train_accy {:.2f}, Test_accy {:.2f}".format(
                    self._cur_task,
                    epoch + 1,
                    self.args['init_epoch'],
                    losses / len(train_loader),
                    train_acc,
                    test_acc,
                )
            else:
                if self._cur_task == 0:
                  self.args['init_epoch']
                else:
                  self.args['init_epoch']=self.args['tuned_epoch']
                info = "Task {}, Epoch {}/{} => Loss {:.3f}, Train_accy {:.2f}".format(
                    self._cur_task,
                    epoch + 1,
                    self.args['init_epoch'],
                    losses / len(train_loader),
                    train_acc,
                )

            prog_bar.set_description(info)

        self._tea_network=self._network.copy()
        logging.info(info)   
    

   